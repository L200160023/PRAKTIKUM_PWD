<html>
<head>
	<title>Halaman Admin</title>
</head>
<body>
	<h1>Welcome to admin page</h1>
	<p>Disini anda masuk sebagai admin, Selamat...</p>
	<br>
	<a href="logout.php">Logout disini</a>
</body>
</html>