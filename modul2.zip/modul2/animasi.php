<html>
	<head>
		<title>
			Animasi
		</title>
	</head>
	<body>
		<marquee align='center' width='100' heigth='65'>
			Teks ini berjalan
		</marquee></br>
	</body>
</html>