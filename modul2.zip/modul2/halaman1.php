<html>
	<head>
		<title>
			Hyperlink
		</title>
	</head>
	<body>
		<H1>Ini adalah halaman pertama</H1></br>
		Untuk pergi ke halaman ke 2, klik <a href='halaman2.php' target='_top'>Disini</a></br>
		Untuk pergi ke halaman google silahkan klik gambar dibawah : </br>
		<a href='http://google.com' target='_blank'> <img src='google.jpg' width='200' height='50' alt='google'></a></br>
		Untuk melihat referensi ttg pemrograman web silahkan klik teks dibawah ini : </br>
		<a href ='#referensi'><b>Lihat referensi ttg pemrograman web</b></a>
		</br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
		</br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
		<a name='referensi'><b>Referensi pemrograman web</b></a></br>
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		Disini adalah teks berisi tentang referensi pemrograman web.
		</br>
	</body>
</html>