<html>
	<head>
		<title>
			Hyperlink
		</title>
	</head>
	<body>
		<H1>Ini adalah halaman 2</H1></br>
		Untuk kembali ke halaman 1 silahkan klik dibawah ini :</br>
		<a href='Halaman1.php' target='_top'> Kembali</a>
	</body>
</html>