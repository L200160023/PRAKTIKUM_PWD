<html>
	<head>
		<title>
			Tugas 1 modul 2
		</title>
	</head>
	<body>
		<marquee>
			<a href='http://www.yahoo.com' target='_top'><img src='yahoo.jpg' width='100' height='50'></a>
		</marquee>
</html>